package Server.Model.Game;

public class Rook extends Piece {
    public Rook(Color color) {
        super(color);
        super.score = 5;
    }

    @Override
    public void move() {
        // your code
    }
}
