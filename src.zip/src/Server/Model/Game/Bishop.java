package Server.Model.Game;

public class Bishop extends Piece {

    public Bishop(Color color) {
        super(color);
        super.score = 3;
    }

    @Override
    public void move() {
        // your code
    }
}
