package Server.Model.Game;

public class Queen extends Piece {
    public Queen(Color color) {
        super(color);
        super.score = 10;
    }

    @Override
    public void move() {
        // your code
    }
}
