package Server.Model.Game;

public class Knight extends Piece {
    public Knight(Color color) {
        super(color);
        super.score =3;
    }

    @Override
    public void move() {
        // your code
    }
}
