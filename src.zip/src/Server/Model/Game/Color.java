package Server.Model.Game;

public enum Color {White, Black}