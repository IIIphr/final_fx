package Server.Model.Game;

public class King extends Piece {
    public King(Color color) {
        super(color);
    }

    @Override
    public void move() {
        // your code
    }
}
