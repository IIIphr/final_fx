package Server.Model.Game;

public class Pawn extends Piece {
    public Pawn(Color color) {
        super(color);
        super.score =1;
    }

    @Override
    public void move() {
        // your code
    }
}
